<?php

// API Key - see http://admin.mailchimp.com/account/api
$apikey			= 'fe1f2cb02955e5134d09253fecd2b929-us11'; // YOUR MAILCHIMP APIKEY
    
// A List Id to run examples against. use lists() to view all
// Also, login to MC account, go to List, then List Tools, and look for the List ID entry
$listId			= 'adf0e21abb'; // YOUR MAILCHIMP LIST ID - see lists() method
    
// A Campaign Id to run examples against. use campaigns() to view all
$campaignId		= ''; // YOUR MAILCHIMP CAMPAIGN ID - see campaigns() method

// just used in xml-rpc examples
$apiUrl			= 'http://api.mailchimp.com/1.3/';
    
?>
